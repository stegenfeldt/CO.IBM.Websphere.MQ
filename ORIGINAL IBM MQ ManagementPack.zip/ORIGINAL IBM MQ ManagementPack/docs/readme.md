# Damati System Center

Self Developed Management Packs for SCOM 2007 R2 and SCOM 2012

##IBM WebSphere MQ Management Pack Guide for Operations Manager 2007
Mohammad F. Damati
Published: July 2013
Send suggestions and comments about this document to DamatiMan@Hotmail.com or DamatiMan@Gmail.com

### Revision History
Release Date Changes
July 2013 - Original release of this guide

## Introduction to the IBM Websphere MQ Management Pack for Operations Manager

IBM® WebSphere® MQ can transport any type of data as messages, enabling businesses to build flexible, reusable architectures such as service-oriented architecture (SOA) environments. It works with a broad range of computing platforms, applications, web services and communications protocols for security-rich message delivery. WebSphere MQ provides a communications layer for visibility and control of the flow of messages and data inside and outside your organization.
Reference: http://www-03.ibm.com/software/products/us/en/wmq/

### Getting the Latest Management Pack and Documentation

You can find the latest version of Management Pack in the Damati System Center Blog Website (www.DamatiSystemCenter.com)

### Supported Configurations

The IBM MQ Management Pack for System Center Operations Manager is designed to monitor IBM MQ Components. The management pack was tested successfully on following environments:

- System Center Operations Manager 2007 R2 (CU6)
- System Center 2012 Operations Manager SP1
- System Center 2012 Operations Manager SP1 (CU2)
- IBM Websphere MQ Version 6
- IBM Websphere MQ Version 7
- Windows Server 2008 R2
- Windows Server 2012

This Management Pack also supports monitoring clustered IBM MQ components.

### Changes in Versioning
The August 2013 update to this management pack includes the following change:

#### Version Description of changes

- 1.0.0.0 - Initial Release with MQ Server Discovery
- 3.0.0.0 - Initial Release with Discovery of all roles.
- 3.0.4.0 - Add Monitors and Performance Collection Rules
- 3.1.4.0 - Add folders and views
- 3.1.4.1 - Fix monitors script. Remove replace “)” function and insert result into Split array function.
- 3.1.4.2 - Fix Collection Rules script. Remove replace “)” function and insert result into Split array function.

## Getting Started

This section describes the actions you should take before and after you import the management pack, as well as information about customizations.

- Run As Accounts
- SCOM Action Account should be local administrator on IBM MQ Servers in order to work properly with no issues.

### Files to Use

Filename Description
IBM.MQ.mp
IBM MQ Base Management Pack
IBM.MQ.Overrides.xml
Overrides Management pack that contains:

Groups:
- IBM MQ Servers Group
- IBM MQ – Queues – Monitoring Group
- IBM MQ – Listeners – Monitoring Group
- IBM MQ – Channels – Monitoring Group

### How to Import the IBM MQ Management Pack
For instructions about importing a management pack, see How to Import a Management Pack in Operations Manager 2007 (http://go.microsoft.com/fwlink/?LinkID=98348).
8
Understanding Management Pack Operations
In the below section, we will provide information about the types of objects the IBM MQManagement Pack for Operations Manager discovers information about classes, how health rolls up, and monitoring scenarios.

### Objects the IBM MQ Management Pack Discovers

The IBM MQ Management Pack discovers the object types described in the following table. Not all of the objects are automatically discovered. Refer to below table for more information about discovery.
Class Discovery Summary Discovery Name Class Discovered Target Frequency Enabled?
IBM MQ Server Discovery
IBM.MQ.Server
Windows Computer
7 Days
Enabled for IBM MQ – Servers Group. (IBM.MQ.Overrides Management Pack)
IBM MQ Queue Manager Discovery
IBM MQ Queue Manager
IBM MQ Server
7 Days
Enabled By Default
IBM MQ Channel Discovery
IBM MQ Channel
IBM MQ Queue Manager
7 Days
Enabled By Default
IBM MQ Listener Discovery
IBM MQ Listener
IBM MQ Queue Manager
7 Days
Enabled By Default
IBM MQ Queue Discovery
IBM MQ Queue
IBM MQ Queue Manager
7 Days
Enabled By Default
IBM MQ Queue Properties Discovery
IBM MQ Queue
IBM MQ Queue
7 Days
False
9
### Classes
The following diagram shows the classes defined in this management pack.
Windows Computer
IBM MQ Server
IBM MQ Channel IBM MQ Listener IBM MQ Queue
IBM MQ Queue Manager
Hosts
Hosts
Hosts Hosts
Hosts
10
### Key Monitoring Scenarios
The following table provides a summary of the monitors to be created for IBM MQ Management Pack.
A summary of monitors and the details for each monitor are provided in the following tables:
### IBM MQ Server Monitors
### IBM MQ Queue Manager Monitors
### IBM MQ Channel Monitors
### IBM MQ Listener Monitors
### IBM MQ Queue Monitors
Monitor Summary Target Type Aggregate Name Enabled?
IBM MQ Server
Unit
Availability
MQ_Installation1 Service Monitor
Yes
IBM MQ Queue Manager
Unit
Availability
Queue Manager Status Monitor
Yes
Dependency Monitor
Availability
Queue Manager Channels Monitor
Yes
Dependency Monitor
Availability
Queue Manager Listeners Monitor
Yes
Dependency Monitor
Availability
Queue Manager Queues Monitor
Yes
IBM MQ Channel
Unit
Availability
Channel Status Monitor
Enabled on (IBM MQ - Channel Monitoring – Enabled) Group
IBM MQ Listener
Unit
Availability
Listener Status Monitor
Enabled on (IBM MQ - Listener Monitoring – Enabled) Group
IBM MQ Queue
Aggregate Monitor
Availability
Queue Depth and IPPROCS Monitor
Yes
Unit
Queue Depth and IPPROCS Monitor
Queue IPPROCS Monitor
Enabled on (IBM MQ – Queue Monitoring – Enabled) Group
Unit
Queue Depth and IPPROCS Monitor
Queue Current Depth Monitor
Enabled on (IBM MQ - Queue Monitoring – Enabled) Group
11
### Placing Monitored Objects in Maintenance Mode
When a monitored object, such as a computer or distributed application, goes offline for maintenance, Operations Manager detects that no agent heartbeat is being received and, as a result, might generate numerous alerts and notifications. To prevent alerts and notifications, place the monitored object into maintenance mode. In maintenance mode, alerts, notifications, rules, monitors, automatic responses, state changes, and new alerts are suppressed at the agent.
Appendix: Monitors and Overrides for Management Packs
This section provides detailed procedures and scripts that you can use to display rules and other information about the management packs you import.
### How to View Management Pack Details
For more information about a monitor and the associated override values, see the knowledge for the monitor.
To view knowledge for a monitor
1. In the Operations Console, click the Authoring button.
2. Expand Management Pack Objects, and then click Monitors.
3. In the Monitors pane, expand the targets until you reach the monitor level. You can also use the Search box to find a particular monitor.
4. Click the monitor, and in the Monitors pane, click View knowledge.
5. Click the Product Knowledge tab.
### How to Display Monitors for a Management Pack
To use the Command Shell to display a list of outputs for a management pack's monitors and overrides, use the following procedure.
To display monitors for a management pack
1. In the Command Shell, type the following command:
get-monitor -managementPack name.mp | export-csv filename
2. A .csv file is created. You can open the .csv in Microsoft Excel.
Note
In Excel, you may be required to specify that the .csv file is a text file.
For example, the command below retrieves data for the monitors associated with one of the core management packs:
get-monitor -managementPack System.Health.Library.mp | export-csv "C:\monitors.csv"
### How to Display Overrides for a Management Pack
To display overrides for a management pack use the following procedure.
12
To display overrides for a management pack
1. In the Command Shell, type the following command:
get-override -managementPack name.mp | export-csv filename
2. A .csv file is created. You can open the .csv file in Excel.
Note
In Excel, you may be required to specify that the .csv file is a text file.
For example, this command displays the overrides for one of the core management packs:
get-override -managementPack Microsoft.SystemCenter.OperationsManager.Internal.mp | export-csv "c:\overrides.csv"
### How to Display All Management Pack Rules
Use the following procedure to display a list of rules for the management packs that you imported. You can view the list of rules in Excel.
To display management pack rules
1. In your management server, click Programs, and then click System Center.
2. Click Command Shell.
3. In the Command Shell window, type the following command:
get-rule | select-object @{Name="MP";Expression={ foreach-object {$_.GetManagementPack().DisplayName }}},DisplayName | sort-object -property MP | export-csv "c:\rules.csv"
4. A .csv file is created. You can open the .csv file in Excel.
Note
In Excel, you may be required to specify that the .csv file is a text file.
### How to Display Monitor Thresholds
To display monitor thresholds, use the script described in this section. This script works for the majority of monitors. It creates a .csv file that contains the columns shown in the following table, and can be viewed by using Excel.
Column Description
Type
The type of objects the monitor is targeted to
DisplayName
The display name of the monitor
Threshold
The threshold used by the monitor
AlertOnState
Determines whether the monitor generates an alert when the state changes
AutoResolveAlert
Determines whether the generated alert will be automatically resolved when the monitor state returns to green
AlertSeverity
The severity of the generated alert
Run the following script to create the .csv file that displays the monitor thresholds:

```powershell
function GetThreshold ([String] $configuration)
{
$config = [xml] ("<config>" + $configuration + "</config>")
13
$threshold = $config.Config.Threshold
if($threshold -eq $null)
{
$threshold = $config.Config.MemoryThreshold
}
if($threshold -eq $null)
{
$threshold = $config.Config.CPUPercentageThreshold
}
if($threshold -eq $null)
{
if($config.Config.Threshold1 -ne $null -and $config.Config.Threshold2 -ne $null)
{
$threshold = "first threshold is: " + $config.Config.Threshold1 + " second threshold is: " + $config.Config.Threshold2
}
}
if($threshold -eq $null)
{
if($config.Config.ThresholdWarnSec -ne $null -and $config.Config.ThresholdErrorSec -ne $null)
{
$threshold = "warning threshold is: " + $config.Config.ThresholdWarnSec + " error threshold is: " + $config.Config.ThresholdErrorSec
}
}
if($threshold -eq $null)
{
if($config.Config.LearningAndBaseliningSettings -ne $null)
{
$threshold = "no threshold (baseline monitor)"
}
}
return $threshold
}
$perfMonitors = get-monitor -Criteria:"IsUnitMonitor=1 and Category='PerformanceHealth'"
$perfMonitors | select-object @{name="Target";expression={foreach-object {(Get-MonitoringClass -Id:$_.Target.Id).DisplayName}}},DisplayName, @{name="Threshold";expression={foreach-object {GetThreshold $_.Configuration}}}, @{name="AlertOnState";expression={foreach-object {$_.AlertSettings.AlertOnState}}}, @{name="AutoResolveAlert";expression={foreach-object {$_.AlertSettings.AutoResolve}}}, @{name="AlertSeverity";expression={foreach-object {$_.AlertSettings.AlertSeverity}}} | sort Target, DisplayName | export-csv "c:\monitor_thresholds.csv"
```

14
### How to Display Performance Collection Rules
To display performance collection rules, use the script in this section. This script works for the majority of monitors. It creates a .csv file that with the following columns, and you can view it by using Excel.
Column Description
WriteAction
Contains information about where the performance counter is written
WriteToDB or CollectionPerformanceData
Writes to the Operations Manager database
WriteToDW or CollectPerfDataWarehouse
Writes to the data warehouse
WC
Stores baseline data for a performance counter into the Operations Manager database
To display the performance collection rules present in the management group, run the following script:

```powershell
function GetPerfCounterName ([String] $configuration)
{
$config = [xml] ("<config>" + $configuration + "</config>")
return ($config.Config.ObjectName + "\" + $config.Config.CounterName)
}
function GetFrequency ([String] $configuration)
{
$config = [xml] ("<config>" + $configuration + "</config>")
$frequency = $config.Config.Frequency;
if($frequency -eq $null)
{
$frequency = $config.Config.IntervalSeconds;
}
return ($frequency)
}
function GetDisplayName($performanceRule)
{
if($performanceRule.DisplayName -eq $null)
{
return ($performanceRule.Name);
}
else
{
return ($performanceRule.DisplayName);
}
}
function GetWriteActionNames($performanceRule)
{
$writeActions = "";
foreach($writeAction in $performanceRule.WriteActionCollection)
{
15
$writeActions += " " + $writeAction.Name;
}
return ($writeActions);
}
$perf_collection_rules = get-rule -criteria:"Category='PerformanceCollection'"
$perf_collection_rules | select-object @{name="Type";expression={foreach-object {(Get-MonitoringClass -id:$_.Target.Id).DisplayName}}},@{name="RuleDisplayName";expression={foreach-object {GetDisplayName $_}}} ,@{name="CounterName";expression={foreach-object {GetPerfCounterName $_.DataSourceCollection[0].Configuration}}},@{name="Frequency";expression={foreach-object {GetFrequency $_.DataSourceCollection[0].Configuration}}},@{name="WriteActions";expression={foreach-object {GetWriteActionNames $_}}} | sort Type,RuleDisplayName,CounterName | export-csv "c:\perf_collection_rules.csv"
```


Appendix: Reports
Currently no out of box reports available for this management pack.
Appendix: Views
The following table lists the views that should be created for the management pack.
Views Name/Folder Type Details
Server State
State
Health State of IBM MQ Servers Discovered
Queue Managers
State
Health Stats of IBM MQ Queue Managers
Channels State
State
Health Stats of IBM MQ Channels
Channels Performance
Performance
Performance View for channels
Listeners State
State
Health Stats of IBM MQ Listeners
Listeners Performance
Performance
Performance View for Listeners
Queues State
State
Health Stats of IVM MQ Queues
Queues Performance
Performance
Performance View for Queues
16
Appendix: Rules
Data collection rules Name Type Details Interval Enabled
Sessions
Performance Collection
Collect number of session on Listener
5 Minutes
Enabled on (IBM MQ - Listener Monitoring – Enabled) Group
IPPROCS
Performance Collection
Number of Applications reading from this queue
5 Minutes
Enabled on (IBM MQ - Queue Monitoring – Enabled) Group
OPPROCS
Performance Collection
Number of Applications writing on this queue
5 Minutes
Enabled on (IBM MQ - Queue Monitoring – Enabled) Group
CURDEPTH
Performance Collection
Collect Current Queue Depth
5 Minutes
Enabled on (IBM MQ - Queue Monitoring – Enabled) Group
Appendix: Monitors Name Type Details Interval Enabled?
MQ_Installation1 Service Monitor
Unit
Monitor IBM MQ Installation1 Windows Service status
Live Monitor
Yes
Queue Manager Status Monitor
Unit
Queue Manager Status
2 Minutes
Yes
Queue Manager Channels Monitor
Dependency Monitor
Monitor overall health of Channels
Live Monitor
Yes
Queue Manager Listeners Monitor
Dependency Monitor
Monitor overall health of Listeners
Live Monitor
Yes
Queue Manager Queues Monitor
Dependency Monitor
Monitor overall health of Queues
Live Monitor
Yes
Channel Status Monitor
Unit
Monitor Channel Status
2 Minutes
Enabled on (IBM MQ - Channel Monitoring – Enabled) Group
Listener Status Monitor
Unit
Monitor Listener Status
2 Minutes
Enabled on (IBM MQ - Listener Monitoring – Enabled) Group
Queue Depth and IPPROCS Monitor
Unit
Number of Applications reading from this queue
2 Minutes
Enabled on (IBM MQ – Queue Monitoring – Enabled) Group
Queue OPPROCS Monitor
Unit
Number of Applications writing on this queue
2 Minutes
Enabled on (IBM MQ – Queue Monitoring – Enabled) Group
Queue Current Depth Monitor
Unit
Queue Depth and IPPROCS Monitor
2 Minutes
Enabled on (IBM MQ - Queue Monitoring – Enabled) Group